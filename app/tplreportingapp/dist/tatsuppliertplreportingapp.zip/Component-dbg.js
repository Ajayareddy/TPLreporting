sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("tatsupplier.tplreportingapp.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);